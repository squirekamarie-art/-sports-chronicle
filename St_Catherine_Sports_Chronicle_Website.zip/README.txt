ST. CATHERINE HIGH SCHOOL — SPORTS CHRONICLE

How to view:
1. Open index.html in a web browser.
2. To customize it, edit index.html in a text editor.
3. Replace the sample text and gallery placeholders with verified school information and approved photos.

This is a starter website for a Digital Media IA. Check your teacher's requirements before submitting.
